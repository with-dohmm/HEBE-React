import React, { useState, useEffect, useCallback, useRef } from 'react';
import '../../css/Common/Header.css';
import axios from 'axios';

const Header = () => {
  const [sessionToggle, setSessionToggle] = useState(1);
  const [searchToggle, setSearchToggle] = useState(0);
  const [leftMenuToggle, setLeftMenuToggle] = useState(0);
  const [rightMenuToggle, setRightMenuToggle] = useState(0);
  const [searchUnm, setSearchUnm] = useState('');
  const [resultUser, setResultUser] = useState({});
  const [searchUserList, setSearchUserList] = useState([]);

  const searchInput = useRef();

  // 반응형 메뉴 버튼 이벤트 활성화
  useEffect(() => {
    if (document.querySelector('.content') !== null) {
      document.querySelector('.content').addEventListener('click', () => {
        setLeftMenuToggle(0);
        setRightMenuToggle(0);
      });
    }
  }, []);

  // search value = '';
  const searchReset = () => {
    // document.querySelector('.search-input').value = '';
    searchInput.current.value = '';
  }

  // setSearchToggle 바뀔 때 마다 value 초기화
  useEffect(() => {
    searchReset();
  }, [searchToggle]);

  // 유저 검색 api
  const apiSearch = () => {
    if (searchInput.current.value.length > 1) {
      axios.post('/api/search', null, { params: {
        unm: searchUnm
      } })
      .then((response) => {
        if (response.data[0].unm === undefined) {
          setSearchUserList([{unm: '검색 결과가 없습니다.'}]);
        } else {
          setSearchUserList(response.data);
        }
      })
      .catch((error) => {
        console.log(error);
      })
      searchReset();
    } else {
      alert('2글자 이상 입력해주세요.');
    } 
  }

  const userList = searchUserList.map((item, i) => 
    <div 
      key={i}
      className="search-modal-profile"
      onClick={() => {document.location.href = "/diary/" + item.iuser}}
    >
      <img className={item.profileImg === undefined ? "search-modal-profileImg hidden" : "search-modal-profileImg"}
        src={process.env.PUBLIC_URL + item.profileImg}>
      </img>
      <span className="search-modal-profileContent">
        <span>{item.unm}</span>
        <span>{item.introduction}</span>
      </span>
    </div>
  )

  // 수정 필수
  return (
    <div className="header">
      <div className="mobile-menu"><i className="fas fa-bars" onClick={() => {setLeftMenuToggle(leftMenuToggle === 0 ? 1 : 0); setRightMenuToggle(0)}}></i></div>
      <div className="logo"><a href="/">HEBE</a></div>
      <div className="header-center">
        <div>
          <span><a href="/">Home</a></span>
          <span><a href="/todo">To Do</a></span>
          <span><a href="/diary/1">My Diray</a></span>
          <span><a href="/myFav/1">Favorite</a></span>
        </div>
      </div>
      <div className={(leftMenuToggle === 0 ? 'left-hidden-menu' : 'left-hidden-menu display-inline-block')}>
        <span><a href="/">Home</a></span>
        <span><a href="/todo">To Do</a></span>
        <span><a href="/diary/1">My Diary</a></span>
        <span><a href="/myFav/1">Favorite</a></span>
      </div>
      <div className="header-right">
        <span className="my-page-btn"><a href="#">{sessionToggle === 1 ? 'My Page' : 'Join'}</a></span>
        <span className="logout-btn"><a href="#">{sessionToggle === 1 ? 'Log out' : 'Log in'}</a></span>
        <i className="fas fa-search" onClick={() => setSearchToggle(searchToggle === 0 ? 1 : 0)}></i>
      </div>
      <div className="right-dot"><i className="fas fa-ellipsis-v" onClick={() => {setRightMenuToggle(rightMenuToggle === 0 ? 1 : 0); setLeftMenuToggle(0)}}></i></div>
      <div className={(rightMenuToggle === 0 ? 'right-hidden-menu' : 'right-hidden-menu display-inline-block')}>
        <div>My Page</div>
        <span></span>
        <div onClick={() => {setSearchToggle(searchToggle === 0 ? 1 : 0); setRightMenuToggle(0);}}>Search</div>
        <span></span>
        <div>Log out</div>
      </div>
      <div 
        className={(searchToggle === 0 ? 'search-modal-background' : 'search-modal-background display-inline-block')}
        onClick={() => {
            setSearchToggle(searchToggle === 0 ? 1 : 0); 
            setSearchUserList([]);
            searchInput.current.value = '';
          }
        }  
      >
      </div>
      <div className={(searchToggle === 0 ? 'search-modal-box' : 'search-modal-box display-inline-block')}>
        <input 
          ref={searchInput}
          className="search-input" 
          type="text" 
          placeholder="search user" 
          onChange={(e) => setSearchUnm(e.target.value)}
          onKeyPress={(e) => {if (e.key === 'Enter') {apiSearch()}}}
        >
        </input>
        <i className="fas fa-search" onClick={apiSearch}></i>
        {userList}
      </div>
    </div>
  );
}

export default Header;